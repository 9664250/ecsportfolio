// Cassie Knoll || 26 Mar || Timer
// If you can't hear the alarm, then turn up the sound. It's kinda quiet.
import processing.sound.*;
SoundFile alarm;

Button btnStart, btnStop, btnReset;
int totalTime = 10;
int startTime = 0;
int timeLeft = 0;
boolean running = false;

void setup() {
  size(500, 500);
  alarm = new SoundFile(this, "alarm.mp3");
  btnStart = new Button(100, 80, 100, 30, "Start", color(255), color(1));
  btnStop = new Button(250, 80, 100, 30, "Stop", color(255), color(1));
  btnReset = new Button(400, 80, 100, 30, "Reset", color(255), color(1));
  timeLeft = totalTime;
}

void draw() {
  background(127);
  
  if(running == true) {
    int elapsed = (millis() - startTime)/1000;
    timeLeft = totalTime - elapsed;
    
    if(timeLeft <= 0) {
      timeLeft = 0;
      running = false;
      alarm.play();
    }
    
  }
  
  btnStart.display();
  btnStart.hover();
  btnStop.display();
  btnStop.hover();
  btnReset.display();
  btnReset.hover();
  
  fill(180);
  rect(width/2, height/2, width-100, 200);
  textSize(100);
  fill(1);
  text(timeLeft, width/2, 250);
  
}

void mousePressed() {
  if(btnStart.over == true) {
    running = true;
  }
  if(btnReset.over == true) {
    startTime = millis();
  }
  if(btnStop.over == true) {
    running = false;
  }
}
